﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Validación_de_Usuario01
{
    public partial class Form1 : Form
    {
        //metodo del USUARIO

        string Usuario = "admin";

        int ingresar = 0;
        string[] accesoUsuarios = new string[10]; //Construccion del arreglo uni
        int validacionUsarios(string nombreUsuario)
        {
            int casillaUsuario = 0;
            for(int i=0;i<10;i++)
                if(nombreUsuario == accesoUsuarios[i])
                {

                    casillaUsuario = i;
                    break;
                }
            return casillaUsuario;
        }


        //Metdo de LA CONTRASEÑA

        string[] contraUsuarios = new string[10]; //Construccion del arreglo uni

        bool validacionContra(int casillaUsuario, string paswordUsuario)
        {

            bool contraValidado = true;

            if (paswordUsuario == contraUsuarios[casillaUsuario] )
        
            {

                
                    
                    Form2 contraValido = new Form2();
                    contraValido.Show();


            }
            else
            {
                Form3 form3= new Form3();
                form3.Show();
                contraValidado = false;
            }
            return contraValidado;
            
        }
        

        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            //USUARIOS

            accesoUsuarios[0] = "Victor";
            accesoUsuarios[1] = "Isai";
            accesoUsuarios[2] = "Fernando";
            accesoUsuarios[3] = "Berenice";
            accesoUsuarios[4] = "Peter";


            //CONTRASEÑA DE USUARIOS

            contraUsuarios[0] = "unitec";
            contraUsuarios[1] = "mac";
            contraUsuarios[2] = "windows";
            contraUsuarios[3] = "123";
            contraUsuarios[4] = "12teams";
        }




        //Boton de ACCEDER 
        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("" + validacionContra (validacionUsarios(textBox1.Text),textBox2.Text));

         
        }

        //Boton de Cerrar
        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Regrese Pronto");
            Application.Exit();
        }

       
    }
}
